const { Message } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let channel =
      msg.mentions.channels.first() ||
      msg.guild.channels.cache.get(args[0]) ||
      msg.channel;
    let baseData = await db.tableAsync("base");
    if (
      (await baseData.get(`logChannel_${msg.guild.id}`)) &&
      channel.id == (await baseData.get(`logChannel_${msg.guild.id}`))
    ) {
      await baseData.delete(`logChannel_${msg.guild.id}`);
      msg.react("🗑");
      msg.reply({
        allowedMentions: { repliedUser: false },
        content: "🗑 تم أيقاف نظام اللوج",
      });
      event.emit("log", msg.guild, {
        author: msg.author,
        date: new Date(),
        value: "حذف روم اللوج",
      });
      return;
    }
    await baseData.set(`logChannel_${msg.guild.id}`, channel.id);
    msg.react("✅");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "📃 تم تفعيل نظام اللوج في روم <#" + channel.id + ">",
    });
    event.emit("log", msg.guild, {
      author: msg.author,
      date: new Date(),
      value: "تحديد روم اللوج",
    });
  }
};
