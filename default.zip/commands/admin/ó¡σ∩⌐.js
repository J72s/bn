const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let bank = await db.tableAsync("bank");
    let user =
      msg.mentions.users.first() || msg.guild.members.cache.get(args[0])?.user;
      if (user?.bot) return msg.reply("اقول وخر عن البوتات 😡")
    if (!user)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
>>> تصفير @منشن`);
    //if (user.id == msg.author.id) return msg.reply("انت بتعمل ايه يسطا :eyes:");
    if (user?.bot) return msg.reply("اقول وخر عن البوتات 😡");

    await bank.set(`money_${user.id}`, 0);
    msg.react("💰");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: "تم تصفير الشخص بنجاح 👍",
    });
    event.emit("log", msg.guild, {
        author: msg.author,
        date: new Date(),
        value: `تم تصفير <@!${user.id}>`,
      });
  }
};
