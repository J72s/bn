const { Message, Embed, EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return true;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let bank = await db.tableAsync("bank");
    let amount = args[1];
    let user =
      msg.mentions.users.first() || msg.guild.members.cache.get(args[0])?.user;
      if (user?.bot) return msg.reply("اقول وخر عن البوتات 😡")
    if (!user || !amount)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
>>> عطه @منشن المبلغ`);
    if (user?.bot) return msg.reply("يسطا دا بوت يسطا خخ");
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    if (amount.includes(".") || amount.includes("-") || !isNumber(amount))
      return msg.reply("يرجى ادخال رقم صحيح ");
    let userCrrancy = (await bank.get(`money_${user.id}`)) ?? "0";
    await bank.set(
      `money_${user.id}`,
      String(Number(userCrrancy) + Number(amount))
    );
    msg.react("💰");
    msg.reply({
      allowedMentions: { repliedUser: false },
      content: `جتك هدية من مدير البنك \`${amount}\`  <@!${user.id}>`,
      
    });
    event.emit("log", msg.guild, {
        author: msg.author,
        date: new Date(),
        value: `زيادة مبلغ مقادره \`${amount}\` الى <@!${user.id}>`,
      });
  }
};
