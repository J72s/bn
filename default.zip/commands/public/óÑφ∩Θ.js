const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");
    if ((await base.get(`حوالات_${msg.guild.id}`)) == true)
      return msg.reply("نظام الحوالات معطل مؤقتاََ ");
    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/main.png";

    let amount = args[1];
    let user =
      msg.mentions.users.first() || msg.guild.members.cache.get(args[0])?.user;
      if (user?.bot) return msg.reply("احد قالك اني محتاج حوالتك وفرها")
    if (!user || !amount)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
>>> تحويل @منشن المبلغ`);
    if (user.id == msg.author.id)
      return msg.reply(
        "يعني بتزيد فلوسك كذا ؟"
      );
    if (user?.bot) return msg.reply("؟");
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    let yourCarrancy = (await bank.get(`money_${msg.author.id}`)) ?? "0";
    let his_herCarrancy = (await bank.get(`money_${user.id}`)) ?? "0";

    if (amount == "نص") amount = Number(yourCarrancy) / 2;
    if (amount == "ربع") amount = Number(yourCarrancy) / 4;
    if (amount == "كامل") amount = Number(yourCarrancy);
    if (amount == "كل") amount = Number(yourCarrancy);

    amount = String(amount);
    if (amount.includes(".") || amount.includes("-") || !isNumber(amount))
      return msg.reply("يرجى ادخال رقم صحيح ");
    if (Number(amount) > Number(yourCarrancy))
      return msg.reply("ليس لديك رصيد كافي");
    await bank.set(
      `money_${msg.author.id}`,
      String(Number(yourCarrancy) - Number(amount))
    );
    await bank.set(
      `money_${user.id}`,
      String(Number(his_herCarrancy) + Number(amount))
    );
    async function createCanvas() {
      const image = await loadImage(imageURL);

      const sacandStage = new Canvas(700, 250)
        .printImage(image, 0, 0, 700, 250)
        .setColor("#000000")
        .setTextFont("28px Impact")
        .printText(msg.author.username, 80, 180)
        .printText(amount.toString() + "$", 80, 220)
        .setTextAlign("left")
        .setColor("#ffffff")
        .setTextFont("bold 48px Cairo")
        .printText("تحويل جديد", 460, 140)
        .setTextFont("bold 24px Cairo")
        .printText(". تم خصم المبلغ المذكور ثم تحويله", 360, 180)
        .pngAsync();
      let tabel = await db.tableAsync("base");
      let imageB = await tabel.get(`image_${msg.guild.id}`);

      if (imageB) {
        const lastImage = await loadImage(imageB);
        const last = new Canvas(700, 250)
          .printImage(lastImage, 0, 0, 700, 250)
          .setGlobalAlpha(0.9)
          .printImage(await loadImage(await sacandStage), 0, 0, 700, 250)
          .pngAsync();

        return await last;
      } else return await sacandStage;
    }

    let resultImage = new AttachmentBuilder(await createCanvas(), {
      name: "7lm.png",
    });
    let msi = await msg.reply({ files: [resultImage] });
    if (isEmbed)
      msi.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(embedColor)
            .setImage("attachment://7lm.png"),
        ],
      });
  }
};
