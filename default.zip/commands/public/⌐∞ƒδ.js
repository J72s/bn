const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");

    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/main.png";

    let amount = args[1];
    let user =
      msg.guild.members.cache.get(args[0])?.user || msg.mentions.users.first();
    if (user?.bot) return msg.reply("هاه ؟؟ :)");
    if (!user || !amount)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
      >>> رهان @منشن المبلغ`);
    if (user.id == msg.author.id) return msg.reply("تراهن نفسك ؟ 🙂");

    await msg
      .reply({
        embeds: [
          {
            title: "طلب رهان",
          },
        ],
      })
      .then(async (m) => {
        await m.react("✅");
        await m.react("❌");
        await m
          .createReactionCollector({
            filter: (args_0, user2) => user2.id == user.id,
            max: 1,
          })
          .on("collect", async (reaction, user) => {
            await m.reactions.removeAll();
            if (reaction.emoji.name == "✅") {
              let current = (await bank.get(`money_${msg.author.id}`)) ?? "0";
              let current2 = (await bank.get(`money_${user.id}`)) ?? "0";
              await bank.set(
                `money_${msg.author.id}`,
                String(Number(current) - Number(amount))
              );
              await bank.set(
                `money_${user.id}`,
                String(Number(current2) - Number(amount))
              );

              let winner = Math.floor(Math.random() * 2);
              let winnerU = winner == 0 ? msg.author : user;

              await bank.set(
                `money_${winnerU.id}`,
                String(Number(current) + Number(Number(amount) * 2))
              );

              async function createCanvas() {
                const image = await loadImage(imageURL);

                const sacandStage = new Canvas(700, 250)
                  .printImage(image, 0, 0, 700, 250)
                  .setColor("#000000")
                  .setTextFont("28px Impact")
                  .printText(winnerU.username, 80, 180)
                  .printText(
                    Number(Number(amount) * 2).toString() + "$",
                    80,
                    220
                  )
                  .setTextAlign("left")
                  .setColor("#ffffff")
                  .setTextFont("bold 48px Cairo")
                  .printText("!!لقد فزت بالرهان", 345, 140)
                  .setTextFont("bold 26px Cairo")
                  .printText("تم أيداع المبلغ في حسابكم", 400, 180)
                  .pngAsync();

                let tabel = await db.tableAsync("base");
                let imageB = await tabel.get(`image_${msg.guild.id}`);

                if (imageB) {
                  const lastImage = await loadImage(imageB);
                  const last = new Canvas(700, 250)
                    .printImage(lastImage, 0, 0, 700, 250)
                    .setGlobalAlpha(0.9)
                    .printImage(
                      await loadImage(await sacandStage),
                      0,
                      0,
                      700,
                      250
                    )
                    .pngAsync();

                  return await last;
                } else return await sacandStage;
              }
              let resultImage = new AttachmentBuilder(await createCanvas(), {
                name: "7lm.png",
              });
              let msi = await m.edit({ files: [resultImage], embeds: [], content: `**الفائز : <@!${winnerU.id}> 🎉**` });
              if (isEmbed)
                msi.edit({
                  embeds: [
                    new EmbedBuilder()
                      .setColor(embedColor)
                      .setImage("attachment://7lm.png"),
                  ],
                });
            } else {
              m.edit({
                embeds: [
                  {
                    title: "تم رفض الرهان 👮‍♂️",
                  },
                ],
              });
            }
          });
      });
  }
};
