const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const { Canvas, loadImage } = require("canvas-constructor/napi-rs");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let حرامية = await db.tableAsync("حرامية");
    let list = await حرامية.get("list");
    if (!list) return msg.reply("لم يحدث عملية نهب الى الأن");
    let arrayOfA7A = [];
    list.forEach((value) => {
      let amount = 0;
      list
        .filter((v) => v.user == value.user)
        .forEach((v) => {
          amount = Number(v.amount) + Number(amount);
        });
      let object = {
        user: value.user,
        amount,
      };
      arrayOfA7A.push(object);
    });
    setTimeout(() => {
      let newArray = [];
      arrayOfA7A.forEach((v) => {
        if (newArray.length == 0) newArray.push(v);
        else {
          if (newArray.find((vu) => vu.user == v.user)) return;
          else newArray.push(v);
        }
      });
      msg.reply({
        embeds: [
          {
            author: {
              name: " قائمة حرامية السيرفر📋",
              icon_url: msg.guild.iconURL(),
            },
            thumbnail: {
              url: msg.guild.iconURL(),
            },
            description: `${newArray
              .sort((v1, v2) => v2.amount - v1.amount)
              .map((v, i) => `**#${i + 1}** | <@${v.user}> : \`${v.amount}$\``)
              .join("\n")}`,
          },
        ],
      });
    }, 450);
  }
};
