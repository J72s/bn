const {
  Message,
  AttachmentBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
} = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const parse = require("parse-ms");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");
    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/graph.png";
    let imageURLr = process.cwd() + "/default/down.png";
    if (
      (await times.get(`تداول_${msg.guild.id}_${msg.author.id}`)) &&
      (await times.get(`تداول_${msg.guild.id}_${msg.author.id}`)) >
        new Date().getTime()
    )
      return msg.reply({
        allowedMentions: { repliedUser: false },
        content: `❌ | \`${
          parse(
            (await times.get(`تداول_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).minutes
        } minutes, ${
          parse(
            (await times.get(`تداول_${msg.guild.id}_${msg.author.id}`)) -
              new Date().getTime()
          ).seconds
        } seconds\`باقي علي التداول :`,
      });
    let amount = args[0];
    if (!amount)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
>>> تداول المبلغ`);
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    let yourCarrancy = (await bank.get(`money_${msg.author.id}`)) ?? "0";

    if (amount == "نص") amount = String(Number(yourCarrancy) / 2);
    if (amount == "ربع") amount = String(Number(yourCarrancy) / 4);
    if (amount == "كامل") amount = String(Number(yourCarrancy));
    if (amount == "كل") amount = String(Number(yourCarrancy));

    if (amount.includes("-") || !isNumber(amount))
      return msg.reply("يرجى ادخال رقم صحيح ");
    if (Number(amount) > Number(yourCarrancy))
      return msg.reply("ليس لديك رصيد كافي");

    msg
      .reply({
        content: "يرجى اختاير الشركة المراد التداول فيها ...",
        components: [
          new ActionRowBuilder().setComponents(
            new StringSelectMenuBuilder()
              .setCustomId("mun")
              .setMaxValues(1)
              .setMinValues(1)
              .setPlaceholder("يرجى اختيار شركة")
              .setDisabled(false)
              .setOptions([
                {
                  label: "شاومي",
                  value: "شاومي",
                },
                {
                  label: "تسلا",
                  value: "تسلا",
                },
                {
                  label: "ان سي ار",
                  value: "ان سي ار",
                },
                {
                  label: "انتيل",
                  value: "انتيل",
                },
                {
                  label: "ساب فاير",
                  value: "ساب فاير",
                },
                {
                  label: "سامسونج",
                  value: "سامسونج",
                },
                {
                  label: "ابل",
                  value: "ابل",
                },
                {
                  label: "يونيون اير",
                  value: "يونيون اير",
                },
                {
                  label: "توشيبا",
                  value: "توشيبا",
                },
                {
                  label: "اتش بي",
                  value: "اتش بي",
                },
                {
                  label: "ايه ام دي",
                  value: "ايه ام دي",
                },
                {
                  label: "اوبو",
                  value: "اوبو",
                },
                {
                  label: "ال جي",
                  value: "ال جي",
                },
                {
                  label: "تورنيدو",
                  value: "تورنيدو",
                },
                {
                  label: "سوني",
                  value: "سوني",
                },
                {
                  label: "ميكروسوفت",
                  value: "ميكروسوفت",
                },
              ])
          ),
        ],
      })
      .then((m) =>
        m
          .createMessageComponentCollector({
            max: 1,
            filter: ({ user }) => user.id == msg.author.id,
          })
          .on("collect", async (i) => {
            let choose = i.values[0];
            await i.deferUpdate().catch(() => {});
            await bank.set(
              `money_${msg.author.id}`,
              String(Number(yourCarrancy) - Number(amount))
            );

            let types = ["-", "+"];
            let presantage = Math.floor(Math.random() * 100) + 1;
            let type = types[Math.floor(Math.random() * 2)];
            let newAmount;
            let crs = Number(amount) * Number(presantage / 100);
            if (type == "-") newAmount = Number(amount) - crs;
            if (type == "+") newAmount = Number(amount) + crs;
            await bank.set(
              `money_${msg.author.id}`,
              String(
                Number(await bank.get(`money_${msg.author.id}`)) +
                  Number(newAmount)
              )
            );

            async function createCanvas() {
              const image = await loadImage(imageURL);
              const imager = await loadImage(imageURLr);
              //const downArrow = await loadImage(
                //process.cwd() + "/default/down.png"
             // );
              const avatar = await loadImage(
                msg.author.avatarURL({ size: 2048 })
              );

              const firstStage = new Canvas(700, 250)
                .printImage(image, 0, 0, 700, 250)
                .createRoundedClip(
                  type == "+" ? 480 : 510,
                  type == "-" ? 155 : 50,
                  80,
                  80,
                  360
                )
                .setColor("#000000")
                .createCircularClip(type == "+" ? 520 : 550, type == "-" ? 195 : 90, 40)
                .printImage(avatar, type == "+" ? 480 : 510, type == "-" ? 155 : 50, 80, 80)
                .pngAsync();
                const firstStager = new Canvas(700, 250)
        .printImage(imager, 0, 0, 700, 250)
        .createRoundedClip(
          type == "+" ? 480 : 510,
          type == "-" ? 155 : 50,
          80,
          80,
          360
        )
        .setColor("#000000")
        .createCircularClip(type == "+" ? 520 : 550, type == "-" ? 195 : 90, 40)
        .printImage(avatar, type == "+" ? 480 : 510, type == "-" ? 155 : 50, 80, 80)
        .pngAsync();
              const stageImage = await loadImage(await firstStage);
              const sacandStage = new Canvas(700, 250)
                .printImage(stageImage, 0, 0, 700, 250)
                .setColor(type == "-" ? "#Ff0000" : "#00FF00")
                .setTextFont("28px Impact")
                .printText(presantage + "%", 630, 140)
                .setColor("#808080")
                .setTextFont("48px Cairo")
                .setTextAlign("center")
                .printText(choose, 350, 50)
                .pngAsync();

              if (type == "-") {
                const _stageImage = await loadImage(await firstStager);
                const theardStage = new Canvas(700, 250)
                  .printImage(_stageImage, 0, 0, 700, 250)
                  .setColor(type == "-" ? "#Ff0000" : "#00FF00")
                .setTextFont("28px Impact")
                .printText(presantage + "%", 630, 140)
                .setColor("#808080")
                .setTextFont("48px Cairo")
                .setTextAlign("center")
                .printText(choose, 350, 50)
                  //.printImage(downArrow, 576, 96, 40, 58)
                  .pngAsync();
                return await theardStage;
              } else return await sacandStage;
            }
            async function createCanvas2() {
              let tabel = await db.tableAsync("base");
              let imageB = await tabel.get(`image_${msg.guild.id}`);

              if (imageB) {
                const lastImage = await loadImage(imageB);
                const last = new Canvas(700, 250)
                  .printImage(lastImage, 0, 0, 700, 250)
                  .setGlobalAlpha(0.9)
                  .printImage(
                    await loadImage(await createCanvas()),
                    0,
                    0,
                    700,
                    250
                  )
                  .pngAsync();

                return await last;
              } else return await createCanvas();
            }
            let resultImage = new AttachmentBuilder(await createCanvas2(), {
              name: "JS Store.png",
            });
            times.set(
              `تداول_${msg.guild.id}_${msg.author.id}`,
              new Date().getTime() + 300000
            );
            let msi = await m.edit({
              files: [resultImage],
              content: "_ _",
              components: [],
            });
            if (isEmbed)
              msi.edit({
                embeds: [
                  new EmbedBuilder()
                    .setColor(embedColor)
                    .setImage("attachment://JS Store.png"),
                ],
              });
          })
      );
  }
};
