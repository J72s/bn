const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let zwagat = await db.tableAsync("zwagat");

    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/talak.png";

    let zwagList = (await zwagat.get("list")) ?? [];
    let status = "**انت غير متزوج اصلاََ 🙂**";
    zwagList.forEach((zwag) => {
      if (zwag.man == msg.author.id)
        return (status = "**الخلع بيد الزوجة عزيزي**");
      if (zwag.woman == msg.author.id) status = "ok";
    });
    setTimeout(async () => {
      if (status !== "ok") return msg.reply(status);
      let object = zwagList.find((zwag) => zwag.woman == msg.author.id);
      let user = msg.client.users.cache.get(object.man);
      if (user?.bot) return msg.reply("")
      async function createCanvas() {
        const image = await loadImage(imageURL);
        const avatar = await loadImage(msg.author.avatarURL());
        const avatar2 = await loadImage(user.avatarURL());

        const firstStage = new Canvas(600, 700)
          .printImage(image, 0, 0, 600, 700)
          .setColor("#000000")
          .createCircularClip(150, 270, 90)
          .printImage(avatar, 60, 180, 180, 180)
          .pngAsync();
        const image2 = await loadImage(await firstStage);

        const sacandStager = new Canvas(600, 700)
          .printImage(image2, 0, 0, 600, 700)
          .setColor("#000000")
          .createCircularClip(450, 270, 90)
          .printImage(avatar2, 360, 180, 180, 180)
          .pngAsync();

          const sacandStage = new Canvas(600, 700)
          .printImage(
            await loadImage(await sacandStager),
            0,
            0,
            600,
            700
          )
          .setColor("#FFFFFF")
          .setTextFont("bold700 30px Cairo")
          .setTextAlign("center")
          .printText(
            "تم خلع الزوج وإنهاء العلاقة الزوجية بين",
            300,
            440
          )
          .printText(" الطرفين لعدم التفاهم فيما بينهما", 300, 440 + 40)
          .printText("والله ولي التوفيق", 300, 445 + 80 )
          
          .printText("عوافي تصير بأرقى العوايل", 300, 160 )
          .printText("  ورقة خلع  ", 300, 70 )
          .pngAsync();

        let tabel = await db.tableAsync("base");
        let imageB = await tabel.get(`image_${msg.guild.id}`);

        if (imageB) {
          const lastImage = await loadImage(imageB);
          const last = new Canvas(600, 700)
            .printImage(lastImage, 0, 0, 600, 700)
            .setGlobalAlpha(0.9)
            .printImage(await loadImage(await sacandStage), 0, 0, 600, 700)
            .pngAsync();

          return await last;
        } else return await sacandStage;
      }
      let resultImage = new AttachmentBuilder(await createCanvas(), {
        name: "7lm.png",
      });
      let newList = [];
      zwagList.forEach((zwag) => {
        if (zwag.woman !== msg.author.id) newList.push(zwag);
      });
      await setTimeout(async () => await zwagat.set("list", newList), 1190);
      let msi = await msg.reply({ files: [resultImage] });
      if (isEmbed)
        msi.edit({
          embeds: [
            new EmbedBuilder()
              .setColor(embedColor)
              .setImage("attachment://7lm.png"),
          ],
        });
    });
  }
};
