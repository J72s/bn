const { Message, AttachmentBuilder, EmbedBuilder } = require("discord.js");
const { EventEmitter } = require("node:events");
const { QuickDB } = require("quick.db");
const {
  Canvas,
  loadImage,
  GlobalFonts,
} = require("canvas-constructor/napi-rs");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
GlobalFonts.registerFromPath(process.cwd() + "/utils/Cairo.ttf", "Cairo");
const parse = require("parse-ms");

module.exports = class setBank {
  /**
   *
   * @param {Message} msg
   * @param {{token:string,prefix:string}} config
   * @param {QuickDB} db
   */
  constructor(msg, config, db) {
    this.msg = msg;
    this.config = config;
    this.db = db;
  }
  isAdmin() {
    return false;
  }
  /**
   *
   * @param {string[]} args
   * @param {EventEmitter} event
   * @returns
   */
  async run(args, event) {
    let { msg, config, db } = this;
    let base = await db.tableAsync("base");
    let bank = await db.tableAsync("bank");
    let times = await db.tableAsync("times");
    let isEmbed = (await base.get(`e_${msg.guild.id}`)) ?? false;
    let embedColor = (await base.get(`eColor_${msg.guild.id}`)) ?? "#FFFFFF";
    let imageURL = process.cwd() + "/default/main.png";
    let حمايه = (await times.get(`حمايه_${msg.author.id}`)) ?? 0;
    if (حمايه > new Date().getTime())
      return msg.reply("👮‍♂️ فترت حمايتك لسى مستمره");
    let amount = args[0];
    if (!amount)
      return msg.reply(`**يرجى كتابة الامر بالطريقة الصحيحة**
    >>> حمايه 1`);
    function isNumber(n) {
      return !isNaN(parseFloat(n)) && isFinite(n);
    }
    let yourCarrancy = (await bank.get(`money_${msg.author.id}`)) ?? "0";

    if (amount.includes("-") || !isNumber(amount))
      return msg.reply("يرجى ادخال رقم صحيح ");
    if (Number(amount) > Number(1))
      return msg.reply("الحماية يوم واحد فقط");
    if (Number(700000) > Number(yourCarrancy))
      return msg.reply("**طفران وتدور حماية جيب 700000 الف و احميك**");
    await bank.set(
      `money_${msg.author.id}`,
      String(Number(yourCarrancy) - 700000)
    );
    let calc = 86400000 * Number(amount);
    await times.set(`حمايه_${msg.author.id}`, new Date().getTime() + calc);
    async function createCanvas() {
      const image = await loadImage(imageURL);

      const sacandStage = new Canvas(700, 250)
        .printImage(image, 0, 0, 700, 250)
        .setColor("#000000")
        .setTextFont("28px Impact")
        .printText(msg.author.username, 80, 180)
        .printText("$700000", 80, 220)
        .setTextAlign("left")
        .setColor("#ffffff")
        .setTextFont("bold 48px Cairo")
        .printText(" الحماية الدولية", 385, 140)
        .setTextFont("bold 24px Cairo")
        .printText("تم سحب 700000 ألف من حسابكم لضمان مدة حمايتكم", 185, 180)
        .pngAsync();
      let tabel = await db.tableAsync("base");
      let imageB = await tabel.get(`image_${msg.guild.id}`);

      if (imageB) {
        const lastImage = await loadImage(imageB);
        const last = new Canvas(700, 250)
          .printImage(lastImage, 0, 0, 700, 250)
          .setGlobalAlpha(0.9)
          .printImage(await loadImage(await sacandStage), 0, 0, 700, 250)
          .pngAsync();

        return await last;
      } else return await sacandStage;
    }
    let resultImage = new AttachmentBuilder(await createCanvas(), {
      name: "7lm.png",
    });
    let msi = await msg.reply({ files: [resultImage] });
    if (isEmbed)
      msi.edit({
        embeds: [
          new EmbedBuilder()
            .setColor(embedColor)
            .setImage("attachment://7lm.png"),
        ],
      });
  }
};
